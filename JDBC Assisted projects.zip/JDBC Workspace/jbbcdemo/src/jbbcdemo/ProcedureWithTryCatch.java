package jbbcdemo;

public class ProcedureWithTryCatch {

	public static void main(String[] args) {
		

	}

}
