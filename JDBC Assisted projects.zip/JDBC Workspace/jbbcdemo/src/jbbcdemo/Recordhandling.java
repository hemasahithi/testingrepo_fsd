package jbbcdemo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Recordhandling {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		//1.Load the DB Driver //It Is mandatory
				Class.forName("com.mysql.cj.jdbc.Driver");
				//2.Connect to the DB -use class DriverManager
				 String dburl = "jdbc:mysql://localhost:3306/animated_movies";
				 String username = "root";
				 String password = "Sahithi@sql87";
				 try {
					 Connection con = DriverManager.getConnection(dburl,username,password);
					 Statement statement = con.createStatement();

					    // You can now execute SQL queries using this connection and statement.
					    // For example, to insert a record:
					 String insertQuery = "INSERT INTO animated_movies (Title, Name,Director,Release_year) VALUES ('Second_movie', 'Shinchan','Unknown',1999)";
					    statement.executeUpdate(insertQuery);

					    // To retrieve records:
					    String selectQuery = "SELECT * FROM animated_movies";
					    ResultSet resultSet = statement.executeQuery(selectQuery);

					    // Process the results
					    while (resultSet.next()) {
					        
					        String column1Value = resultSet.getString("Title");
					        String column2Value = resultSet.getString("Name");
					        String column3Value = resultSet.getString("Director");
					        String column4Value = resultSet.getString("Release_year");
					        
					        // Process the retrieved data
					        System.out.println( " Column1: " + column1Value+ ", Column2: " + column2Value+ ", Column3: " + column3Value+ ", Column4: " + column4Value );
					    }

					    // Close the resources
					    resultSet.close();
					    statement.close();
					    con.close();
					} catch (Exception e) {
					    e.printStackTrace();
					
				
				
				System.out.println("Successfully connected to Database");
		
		
		
		
	}

}
}
