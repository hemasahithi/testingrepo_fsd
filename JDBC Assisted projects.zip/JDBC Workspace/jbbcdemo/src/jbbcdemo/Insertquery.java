package jbbcdemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Insertquery {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		//String query = "INSERT INTO Movies VALUES('Title','Generic','Director','Release_year')";
		//1.Load the DB Driver //It Is mandatory
				Class.forName("com.mysql.cj.jdbc.Driver");
				//2.Connect to the DB -use class DriverManager
				 String dburl = "jdbc:mysql://localhost:3306/animated_movies";
				 String username = "root";
				 String password = "Sahithi@sql87";
				 Connection con = DriverManager.getConnection(dburl,username,password);
					System.out.println("Successfully connected to Database");
					//PrepareStatement-->used for executing inser querys with parameter
					String title = "MAD";
					String generic = "Drama/Comedy";
					String director = "Kalyan sankar";
					String release_year = "2023";
					
				PreparedStatement ps = con.prepareStatement("insert into Movies values(?,?,?,?)");
	ps.setString(1, title);
	ps.setString(2, generic);
	ps.setString(3, director);
	ps.setString(4, release_year);
    ps.executeUpdate();	
    System.out.println("Insert Query Executed Successfully");
    
    // Create a SELECT query to retrieve the inserted data
    String selectQuery = "SELECT * FROM Movies WHERE title = ?";
    PreparedStatement selectStatement = con.prepareStatement(selectQuery);
    selectStatement.setString(1, title);

    ResultSet resultSet = selectStatement.executeQuery();

    while (resultSet.next()) {
        String retrievedTitle = resultSet.getString("title");
        String retrievedGeneric = resultSet.getString("generic");
        String retrievedDirector = resultSet.getString("director");
        String retrievedReleaseYear = resultSet.getString("release_year");

        System.out.println("Retrieved Data:");
        System.out.println("Title: " + retrievedTitle);
        System.out.println("Generic: " + retrievedGeneric);
        System.out.println("Director: " + retrievedDirector);
        System.out.println("Release Year: " + retrievedReleaseYear);
    }
    
    
    
    
					
					con.close();
					

					
	}
	
		
   
	
	

}


