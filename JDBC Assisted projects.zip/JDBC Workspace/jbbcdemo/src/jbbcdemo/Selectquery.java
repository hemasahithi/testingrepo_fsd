package jbbcdemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Selectquery {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		//1.Load the DB Driver //It Is mandatory
		Class.forName("com.mysql.cj.jdbc.Driver");
		//2.Connect to the DB -use class DriverManager
		 String dburl = "jdbc:mysql://localhost:3306/animated_movies";
		 String username = "root";
		 String password = "Sahithi@sql87";
		
		Connection con = DriverManager.getConnection(dburl,username,password);
		System.out.println("Successfully connected to Database");
		String query = "select * from Movies";
		
		//send query to the db
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		while(rs.next()) {
			System.out.print("Title:  " +rs.getString("Title")+ "\t");
			System.out.print("Title:  " +rs.getString("Generic")+ "\t");
			System.out.print("Title:  " +rs.getString("Director")+ "\t");
			System.out.print("Title:  " +rs.getString("Release_year")+ "\t");
		}
		con.close();
	}

}

