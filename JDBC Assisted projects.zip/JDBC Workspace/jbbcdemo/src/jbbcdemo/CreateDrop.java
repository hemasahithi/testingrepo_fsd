package jbbcdemo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateDrop {

    public static void main(String[] args) throws ClassNotFoundException, SQLException {
    	Class.forName("com.mysql.cj.jdbc.Driver");
		//2.Connect to the DB -use class DriverManager
		 String dburl = "jdbc:mysql://localhost:3306/animated_movies";
		 String username = "root";
		 String password = "Sahithi@sql87";
		
			String query = "create database Holiday";
			String query1 = "drop database Holiday";
			
			
			
			
			
			
			 Connection con = DriverManager.getConnection(dburl,username,password);
			 Statement stmt = con.createStatement();
			stmt.executeUpdate(query);
			 
			 System.out.println("New Database is created successfully");
			 
                  stmt.executeUpdate(query1);
			 
			 System.out.println("New Database is dropped successfully");
				System.out.println("Successfully connected to Database");
			
    	
    	
    	
    	
    	
    	
    	
    }
}