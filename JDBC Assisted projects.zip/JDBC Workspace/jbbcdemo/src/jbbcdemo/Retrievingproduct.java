package jbbcdemo;


		import java.sql.Connection;
		import java.sql.DriverManager;
		import java.sql.PreparedStatement;
		import java.sql.ResultSet;
		import java.sql.SQLException;

		public class Retrievingproduct {
		    public static void main(String[] args) throws ClassNotFoundException, SQLException {
		        // JDBC URL, Username, and password of MySQL server
		    	Class.forName("com.mysql.cj.jdbc.Driver");
		    	String dburl = "jdbc:mysql://localhost:3306/Products";
		        String username = "root";
		        String password = "Sahithi@sql87";
		        Connection con = DriverManager.getConnection(dburl,username,password);
		        System.out.println("Successfully connected to Database");
		        // Product ID to retrieve
		        int productID = 1234; // Replace with the actual product ID

		        try {
		            // Establish a connection to the database
		            Connection connection = DriverManager.getConnection(dburl, username, password);

		            // SQL query to retrieve product details
		            String sql = "SELECT * FROM products WHERE product_id = ?";
		            PreparedStatement preparedStatement = connection.prepareStatement(sql);
		            preparedStatement.setInt(1, productID);

		            // Execute the query
		            ResultSet resultSet = preparedStatement.executeQuery();

		            // Check if the product with the given ID exists
		            if (resultSet.next()) {
		                // Retrieve and display product details
		                int id = resultSet.getInt("product_id");
		                String name = resultSet.getString("product_name");
		                double price = resultSet.getDouble("product_price");

		                System.out.println("Product ID: " + id);
		                System.out.println("Product Name: " + name);
		                System.out.println("Product Price: " + price);
		            } else {
		                System.out.println("Product with ID " + productID + " not found.");
		            }

		            // Close the resources
		            resultSet.close();
		            preparedStatement.close();
		            connection.close();
		        } catch (SQLException e) {
		            e.printStackTrace();
		        }
	}

}
	
