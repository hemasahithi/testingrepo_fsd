package jbbcdemo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Storedprocedurewithexpectionhandling {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		//1.Load the DB Driver //It Is mandatory
				Class.forName("com.mysql.cj.jdbc.Driver");
				//2.Connect to the DB -use class DriverManager
				 String dburl = "jdbc:mysql://localhost:3306/animated_movies";
				 String username = "root";
				 String password = "Sahithi@sql87";
				 String query = "Call allmovies()";
				 Connection con = null;
				try {
						Class.forName("com.mysql.cj.jdbc.Driver");

						con = DriverManager.getConnection(dburl, username, password);
						System.out.println("Succesfully connected");

						Statement stmt = con.createStatement();

						ResultSet rs = stmt.executeQuery(query);

						while (rs.next()) {

							System.out.print("Title:  " + rs.getString("Title") + "\t");

							System.out.print("Generic:  " + rs.getString("Generic") + "\t");

							System.out.print("Director:  " + rs.getString("Director") + "\t");

							System.out.println("Release Year:  " + rs.getString("Release_year") + "\t");

						}

					} catch (Exception e) {

						System.out.println(e.getMessage());
					} finally {

						con.close();

					}

		

	}

}
