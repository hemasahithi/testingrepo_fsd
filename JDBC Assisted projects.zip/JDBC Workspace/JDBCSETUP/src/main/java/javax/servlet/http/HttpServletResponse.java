package javax.servlet.http;

import java.io.PrintWriter;

public class HttpServletResponse {

	public PrintWriter getWriter() {
		// TODO Auto-generated method stub
		return null;
	}

}
